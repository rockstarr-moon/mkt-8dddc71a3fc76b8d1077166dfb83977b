# rockstarr-outreach-salesnav

Rockstarr AI LinkedIn outreach for clients who won't or can't install a
third-party campaign tool (Interceptly, MeetAlfred, Dripify, Waalaxy).
This plugin drives Sales Navigator directly through the Chrome MCP and
keeps every lead, task, message, and metric in a single Excel workbook
inside the standard `/rockstarr-ai/` folder.

This variant is deliberately minimal. Advanced campaign features
(A/B sequence tests, weighted multi-campaign pacing, per-lead cap
coordination across outreach + nurture, SLA escalations) belong in
`rockstarr-outreach-interceptly` / MeetAlfred / Dripify variants.

## Hard constraints

1. All sends happen in Sales Nav — no 3rd-party outreach tool.
2. A lead belongs to exactly one campaign at a time. No duplicates.
3. Connection requests are capped at **20 per day + 100 per ISO week**
   across all active campaigns regardless of campaign type. Unused
   daily capacity carries forward inside the current ISO week only.
   Weekly ceiling is hard.
4. Every reply routes through `rockstarr-reply` for client approval
   before sending.
5. Before any daily send, `confirm-session` verifies the browser is
   signed into the client's LinkedIn. Mismatch aborts the whole loop.
6. The booking link is **never** handed to the lead. The bot either
   books on the lead's behalf after they agree to a proposed time, or
   the client books manually and calls `mark-booked`.
7. All state lives in `/rockstarr-ai/` per `rockstarr-infra`'s scaffold.

## Campaign types

Each campaign carries a `campaign_type` field on its Campaigns row,
set at draft time and validated at registration:

- **`full-sequence`** (default) — connect request + three-message
  post-accept conversation aimed at opening conversations and
  booking meetings. The original Rockstarr campaign shape; every
  pre-0.1.7 campaign is implicitly this type.
- **`connect-only`** — connection requests only, no post-accept
  sequence. The campaign ends at the accept. Use this for
  network-building or first-degree audience growth where the goal
  is being-in-the-feed, not opening conversations.

Both types share the global 20/day + 100/week cap, the same
saved-search-driven Leads pull, the same `confirm-session` gate,
and the same blank-connect rule. The difference is what happens
after the accept — full-sequence chains into
`generate-message-tasks` and the four-message sequence runs;
connect-only stops at `state=accepted` and the campaign succeeds
on accept-rate alone.

A workspace can run any mix of full-sequence and connect-only
campaigns simultaneously. `daily-connect` round-robins across all
active campaigns regardless of type — LinkedIn account health is
one budget, not two.

## Skills

| Skill | Purpose |
|-------|---------|
| `draft-icp-campaign` | Given an ICP + saved Sales Nav search URL, picks the campaign type (full-sequence or connect-only) and writes the campaign spec — full-sequence specs include filters + 3-step sequence + cadence + exit conditions; connect-only specs include filters + target_lead_count + exit conditions only. Ships inline for V0.1; will migrate to `rockstarr-infra/skills/_shared/`. |
| `register-campaign` | Promote an approved campaign spec, validate against its `campaign_type`, crawl the saved search into Leads, seed initial connect tasks. |
| `crawl-lead-list` | Idempotent crawl of a saved Sales Nav search via Chrome MCP — paginates, scrolls each row into view and waits for it to hydrate, commits only fully-hydrated rows to Leads, and resumes silently across re-invokes (URL-dedup against existing leads for the campaign). Enforces "one campaign per lead" across campaigns. |
| `confirm-session` | Pre-flight: verify the browser is signed in to the client's LinkedIn. Gate on the entire daily loop. |
| `preview-queue` | Daily preview file listing every action the bot plans to take today. Togglable via `stack.md`. |
| `daily-connect` | Compute today's budget (20/day + 100/week math), round-robin across all active campaigns regardless of type, send BLANK connect requests via the `lead_profile_overflow` Chrome MCP path (direct nav to each lead's `/sales/lead/[urn]` page, then the overflow "..." menu — the only path that reliably survives Sales Nav's virtualized saved-search hydration). Pure-JS one-shot click pattern, 60–90s per-lead jitter, full page refresh every 3 successful sends. Four skip rules: Connect–Pending, 1st-degree, no-Connect-option, requires-email (terminal). Only skill that sends connects. |
| `detect-accepts` | Detect newly accepted connections and flip `Leads.state=accepted`. Partition by campaign type — full-sequence accepts chain into `generate-message-tasks`; connect-only accepts are terminal and don't trigger any further tasks. |
| `generate-message-tasks` | On accept (full-sequence campaigns only), seed a 3-step sequence at day-of-accept / +3 / +7. Refuses to run for connect-only campaign leads. |
| `send-scheduled-messages` | Execute `message-step-N` and follow-up tasks due today via Sales Nav messaging. |
| `detect-replies` | Pull inbound messages, append to Replies, cancel pending tasks for the lead, drive `rockstarr-reply` synchronously to stage a draft per inbound, then fire one urgent client email summarizing every newly-staged draft via `rockstarr-infra:notify-reply-ready`. |
| `send-approved-reply` | Send a reply approved by `rockstarr-reply`, seed a 2-day follow-up task. |
| `propose-meeting-times` | Read the availability source (booking link OR Google Calendar) and return 2–3 proposed slots for the reply. Ships inline for V0.1; will migrate to `rockstarr-infra/skills/_shared/`. |
| `book-meeting` | Automated booking path: drive the booking-link form via Chrome MCP once the lead has agreed to a time and supplied the required fields. |
| `mark-booked` | Single source of truth for "a meeting got booked." Flips `Leads.state=booked`, cancels pending tasks, writes a Replies row. |
| `stop-campaign` | Pause (resumable) or stop (permanent) a campaign; cancel pending tasks. |
| `metrics-daily` | End-of-day: one row per active campaign into Metrics (Daily); update ISO-week running totals. |
| `metrics-weekly` | Friday: per-campaign weekly roll-up into Metrics (Weekly). |
| `outreach-weekly-report` | Markdown weekly report from Metrics (Weekly). |
| `backup-workbook` | Weekly snapshot of `outreach-tasks.xlsx` into `/06_reports/data/`. |

Deferred past V0.1: `force-send-today`, `refresh-lead-list`,
`gcal-auto-booking`.

## Preconditions (every client)

Before any skill in this plugin runs, `rockstarr-infra` must have
already produced:

- `/rockstarr-ai/00_intake/client-profile.md`
- `/rockstarr-ai/00_intake/style-guide.md` (explicitly approved)
- `/rockstarr-ai/00_intake/stack.md` with outreach keys set:
  - `outreach_tool: salesnav`
  - `linkedin_expected_profile_url: https://www.linkedin.com/in/...`
  - `outreach_daily_run_time: "09:00"` (client's local time)
  - `outreach_daily_preview: true` (default on)
  - `booking_mode: automated | manual`
  - `availability_source: booking_link | gcal`
  - `booking_link_url:` (if `availability_source: booking_link`)
  - `booking_link_required_fields: [email, phone, company]` (list)
  - `gcal_id:` (if `availability_source: gcal`)
- `/rockstarr-ai/01_knowledge_base/index.md` with first-party processed
  files (campaign copy cites first-party proof).

`rockstarr-infra` must also expose:

- `skills/_shared/stop-slop/` — mandatory final pass on every draft.
  The prose-producing skills in this plugin (`draft-icp-campaign`,
  `outreach-weekly-report`) call it after the style-guide pass and
  before the file lands in `03_drafts/` or `06_reports/`. If
  `stop-slop` is not discoverable, these skills refuse and point the
  user back at `rockstarr-infra`.
- `skills/notify-reply-ready/` — fired by `detect-replies` at the end
  of each run as a single urgent email summarizing every reply draft
  staged on this pass. Ships in `rockstarr-infra >= 0.8.0`. If
  unavailable, `detect-replies` still stages drafts and creates the
  `review-reply` tasks but skips the urgent email and surfaces an
  `infra_too_old` entry in its `notify_skipped_reasons` output. The
  next morning's `approvals-digest` covers the gap.

This plugin also requires:

- `rockstarr-reply >= 0.2.0` — the build that writes the v0.8.0
  front-matter contract `notify-reply-ready` reads (`channel: "reply"`
  + `source_channel`, `inbound_excerpt`, `draft_body`, `path_relative`,
  optional `draft_options[]`). `detect-replies` validates the contract
  on every staged path before handing the list off and drops paths
  with incomplete front-matter.
- `rockstarr-mailer >= 0.2.1` — claude:// URL scheme support for the
  per-draft deep-link in the urgent email.

If `stack.md` is missing any of the outreach keys, skills refuse to run
and point the user back at `rockstarr-infra:capture-stack`.

## Folder contract

```
rockstarr-outreach-salesnav reads:
  00_intake/client-profile.md
  00_intake/style-guide.md
  00_intake/stack.md
  01_knowledge_base/index.md
  01_knowledge_base/processed/**
  02_inputs/outreach/icps/<slug>.md          (client-supplied ICP)
  02_inputs/outreach/lead-lists/<slug>.md    (saved-search URL + notes)
  04_approved/outreach/campaign-<slug>.md    (approved campaign spec)

rockstarr-outreach-salesnav writes:
  02_inputs/outreach/outreach-tasks.xlsx     (SINGLE state-of-truth)
  02_inputs/outreach/queue-<yyyy-mm-dd>.md   (daily preview)
  02_inputs/outreach/_errors.md              (loud failures)
  03_drafts/outreach/campaign-<slug>.md      (campaign draft)
  03_drafts/outreach/replies/<thread>.md     (reply drafts for rockstarr-reply)
  05_published/outreach/<yyyy-mm-dd>.md      (daily activity log)
  06_reports/weekly/outreach-<yyyy-ww>.md    (weekly report)
  06_reports/data/outreach-tasks-backup-<yyyy-ww>.xlsx
```

All paths are relative to the client's `/rockstarr-ai/` root.

## The workbook — single state-of-truth

Every skill reads and writes
`/rockstarr-ai/02_inputs/outreach/outreach-tasks.xlsx`. Every sheet
carries a `campaign_slug` column; all active campaigns share the same
workbook.

| Sheet | Role |
|-------|------|
| Campaigns | One row per campaign. Slug, `campaign_type` (full-sequence / connect-only), ICP ref, lead-list saved-search URL, status (active / paused / stopped), date started, date stopped, target_lead_count, notes. |
| Leads | Union of all leads. LinkedIn URL (primary key), name, company, title, `campaign_slug`, state (queued / connected / accepted / replied / booked / opted-out), date entered each state. A lead belongs to exactly one campaign at a time. |
| Tasks | Work queue. id, lead URL, `campaign_slug`, type (connect / message-step-N / follow-up / review-reply / book-meeting), due date, status (pending / done / cancelled), created-at, completed-at. |
| Connections | Daily log of connection requests sent. |
| Messages | Log of messages sent to connected leads (step number, body). |
| Replies | Log of inbound replies (raw text, classification, handoff state). |
| Metrics (Daily) | One row per campaign per day. |
| Metrics (Weekly) | One row per campaign per ISO week + rates + weekly cap used/remaining. |

Task types:

| Task type | Created by | Completed / cancelled by |
|-----------|------------|--------------------------|
| `connect` | `register-campaign` seeds one per lead; `daily-connect` schedules them. | `daily-connect` on send. Cancelled only by `stop-campaign`. |
| `message-step-N` | `generate-message-tasks` on accept. | `send-scheduled-messages` on send. Cancelled by `detect-replies` or `mark-booked`. |
| `review-reply` | `detect-replies` (hands off to `rockstarr-reply`). | Closed when `rockstarr-reply:approve` fires. Merged if lead sends another message first. |
| `follow-up` | `send-approved-reply` (due = today + 2). | Cancelled by `detect-replies` (new reply) or `mark-booked`; otherwise executed on due-date. |
| `book-meeting` | `draft-reply` when lead has agreed to a time AND supplied the booking-link's required fields. | `book-meeting` runs the form via Chrome MCP; calls `mark-booked` on success, drops `review-reply` on failure. |

## Daily operational loop

The fixed step order (every step degrades gracefully if the prior
produced nothing):

1. `confirm-session` — verify LinkedIn session. Gate on everything below.
2. `preview-queue` — write `queue-<date>.md` (if `outreach_daily_preview: true`).
3. `detect-accepts` → `generate-message-tasks` — seed sequences.
4. `send-scheduled-messages` — execute message-step-N + follow-up tasks due today.
5. `detect-replies` — capture inbound, cancel pending tasks for the lead, drive `rockstarr-reply` synchronously to stage a draft per inbound, fire one urgent email summarizing the batch.
6. `daily-connect` — compute budget, round-robin across campaigns, send connects.
7. `metrics-daily` — roll up today's numbers per campaign; update ISO-week totals.

An optional afternoon pass re-runs `detect-replies` only (no connect
loop). Event-driven paths — `send-approved-reply`, `book-meeting`,
`mark-booked` — run whenever they're triggered.

### Scheduling the loop

Workspaces wire this loop up as one or more scheduled tasks in
Cowork. There are two viable patterns, and the right choice depends
on campaign volume.

**Single-task pattern (default for low-volume workspaces).** One
scheduled task runs steps 1–7 in order at
`stack.md.outreach_daily_run_time`. Simple, the canonical fixed
order maps 1:1 to one task. Use this when:

- The workspace runs at most 1–2 full-sequence campaigns
- Average day produces ≤3 accepts (so step 4 sends ≤3 messages)
- Daily connect budget is well under 20 (e.g., the operator wants
  to ramp gently)

**Split-task pattern (recommended for full-volume workspaces).**
The single-task pattern works mathematically but bumps into a
practical ceiling: Cowork imposes a per-scheduled-task budget on
the number of agent turns a single run can consume (~100 turns as
of this writing). A morning that needs to seed 5–7 M2/M3/M4 sends
*plus* 20 connect attempts *plus* a detect-replies sweep regularly
needs 150–200 turns and is cut off mid-run when the budget is hit.
Splitting into two scheduled tasks gives each side its own budget:

| Task | Time (offset) | Steps | Typical turn cost |
|---|---|---|---|
| `<slug>-outreach-messages` | `outreach_daily_run_time` | confirm-session → preview-queue → detect-accepts → generate-message-tasks → send-scheduled-messages → detect-replies → metrics-daily (partial) | 40–60 turns |
| `<slug>-outreach-connects` | `outreach_daily_run_time + 60 min` | confirm-session → (optional) crawl-on-shortfall → daily-connect | 80–120 turns (mostly daily-connect's 6 turns/send × 20 sends) |

The 60-minute offset is the practical minimum — both tasks open
the same Sales Nav session, and back-to-back runs amplify the SPA
state degradation that `daily-connect`'s page-refresh-every-3-sends
pacing is designed to manage. An hour gives the SPA fresh space
and matches realistic operator-presence windows.

**`crawl-on-shortfall` step (split pattern only).** The connects
task can include a pre-step that calls `crawl-lead-list` when an
active campaign has fewer queued leads than its target. The check
runs as: for each campaign with `status = active`, if
`Leads.count(campaign, state=queued) + today_budget <
target_lead_count × 1.5`, invoke `crawl-lead-list` with that
campaign's slug, saved-search URL, and remaining count.
`crawl-lead-list` is idempotent (since 0.3.0) — re-invoking it
against a campaign that already has some leads picks up from where
the prior partial crawl stopped without duplicating. Skip the step
entirely when the queue is sufficient for today's budget.

### Scheduling environment

Two operational realities to surface to the operator on day one,
because both have caught new clients by surprise:

- **The bot only runs when Claude Desktop is open and the laptop is
  awake.** If your laptop sleeps at the scheduled time, the task
  fires on next launch — i.e., when you wake the laptop. For most
  workdays this is fine (the daily window straddles when you're
  already at your machine), and the slight time jitter is
  ironically a small LinkedIn-anti-spam benefit. For multi-day
  absences or strict-window send-cadence requirements, run the
  laptop in clamshell mode connected to power.
- **Each scheduled task creates its own Chrome MCP tab group.**
  The Chrome MCP API does not expose cross-session group rename or
  merge — every scheduled task's session gets its own auto-named
  group (`<task-name>`). A workspace with the split pattern will
  therefore have at least two outreach groups visible in the tab
  bar (one per scheduled task). This is cosmetic; sends still log
  correctly. Don't write loop prompts that try to consolidate
  groups across sessions — it isn't possible from inside the
  agent.

## Approvals

| Gate | Routes through |
|------|----------------|
| Campaign spec | `rockstarr-infra:approve` on `03_drafts/outreach/campaign-<slug>.md`. `register-campaign` only runs on approved files. |
| Campaign messages | Covered by campaign approval. Per-send does not re-prompt. |
| Replies | Every inbound reply → `rockstarr-reply` → human approve → `send-approved-reply`. |
| Follow-ups | 2-day follow-ups draft fresh on due-date via `rockstarr-reply`. Per-reply gate applies. |
| Bookings | Covered by the approved reply that proposed the times. `book-meeting` runs without a second approval. Set `booking_mode: manual` to disable `book-meeting` entirely. |
| Start / stop | Client triggers `register-campaign` and `stop-campaign`. The bot never starts or stops a campaign on its own. |

No SLA on `review-reply` approvals — stale items surface in the weekly
report's "bot heartbeat" callout. The cross-bot
`rockstarr-infra:approvals-digest` runs every morning and surfaces every
still-pending `review-reply` (and every other awaiting-approval draft
across bots) on the standardized front-matter contract that
`rockstarr-reply >= 0.2.0` writes. The `notify-reply-ready` urgent
email fired by `detect-replies` is an *acceleration* of the digest for
the just-staged drafts, not a replacement — a draft staged at 9:14am
appears in the urgent email at 9:15am AND in the next morning's
digest if it hasn't been approved by then.

## Versioning

- `0.1.0` — initial cut. 19 skills, Sales Nav only, booking link OR
  Google Calendar (manual book) for availability.
- `0.1.1` — `draft-icp-campaign` sequence tightened: Message 1 blank
  (LinkedIn default), Message 2 acknowledge/tease, Message 3 invite
  engagement, Message 4 respectful close. No prose-body changes to
  other skills.
- `0.1.2` — `draft-icp-campaign` hardened further: campaign ICP now
  derives from `00_intake/client-profile.md` via an interactive,
  non-destructive per-campaign clarification pass (adjustments
  NEVER write back to `client-profile.md`). Six hard Sequence rules
  added: no "following up" language anywhere, no em dashes in the
  sequence, never announce absence of pitch, anchor phrase stays
  verbatim across Messages 2/3/4, Message 2 is a curiosity opener
  that earns a reply on its own, Message 4 names the ceiling (not
  the pain) in the "X gets attention only when there is time, which
  is never" shape. Self-check pass added as drafting rule 7.
- `0.1.3` — `draft-icp-campaign` tightens Messages 3 and 4 and
  narrows the anchor-phrase rule. Anchor phrase now appears verbatim
  in Message 2 ONLY — Messages 3 and 4 do not repeat it (repetition
  reads as scripted and kills the conversational tone). Message 3
  drops the trailing permission softener ("fine if I send another
  note?" / "OK to stay in touch?") — that kind of line is filler,
  not invitation. Message 4 is renamed from "Ceiling close" to
  "Respectful close" and capped at two or three sentences: one
  specific "weeks get full"–style acknowledgment + one open-door
  line + stop. No anchor restatement, no ceiling restatement, no
  well-wishes, no chase. Rule 4 rewritten, Rule 6 rewritten, new
  Rule 7 added for the softener ban, self-check pass updated.
- `0.1.4` — Stop-slop integration per the Growth OS cross-bot
  contract. `draft-icp-campaign` gains Drafting rule 8: after the
  self-check rewrites, the campaign spec prose and all three
  sequence message bodies (Messages 2, 3, 4) must pass
  `rockstarr-infra:stop-slop` as the final pre-write pass. Order is
  style-guide first, stop-slop last. `outreach-weekly-report` adds
  an equivalent requirement for the prose blocks (week-over-week
  bullets, "What Rachel / Jon should notice," and the narrative
  portion of "Actions for next week"); tables, heartbeat lines, and
  the stale-task callout are exempt as structural artifacts. Both
  skills refuse if `stop-slop` is not discoverable. Produced-by
  stamps bumped.
- `0.1.6` — Three changes shipped together.
  1. `notify-reply-ready` integration. `detect-replies` now drives
     `rockstarr-reply` synchronously to stage a reply draft per
     inbound (instead of just signalling), accumulates the resulting
     paths into `staged_paths[]`, and at end-of-run fires a single
     urgent client email via `rockstarr-infra:notify-reply-ready`
     that summarizes every newly-staged draft with a `claude://`
     deep-link per card. Empty batch = silent skip (the feature).
     `detect-replies` validates each staged path's front-matter
     against the v0.8.0 contract before the call and drops paths
     with incomplete front-matter into `notify_skipped_reasons`.
     Output block gains `drafts_staged`, `book_meeting_handoffs`,
     `notify_message_id`, and `notify_skipped_reasons[]`. Requires
     `rockstarr-infra >= 0.8.0`, `rockstarr-reply >= 0.2.0`,
     `rockstarr-mailer >= 0.2.1`. Existing `rockstarr-reply not
     installed` and per-thread error fallbacks preserved — those
     paths skip the urgent email and let the next morning's
     `approvals-digest` cover the gap.
  2. `draft-icp-campaign` sequence personalization + Message 4 hook
     rewrite. Messages 2 and 3 now open with a literal
     `{first_name}` placeholder (bare-name comma-led OR
     greeting-led, writer's pick per the client's voice);
     `send-scheduled-messages` substitutes from `Leads.name` at
     send time. Message 4 hook is rewritten from a generic empathy
     opener ("weeks get full," "I know you're busy") to a
     benefit-to-ICP hook framed as a future-condition ("when X
     becomes useful," "if Y starts costing you Z") drawn from the
     per-campaign ICP's pain focus + a `kb_sources_used` proof
     point. New Sequence rules 8 (`{first_name}` placeholder
     convention) and 9 (Message 4 benefit-hook spec) added. Self-
     check pass extended with eight new checks covering placeholder
     presence on Messages 2/3, placeholder absence on Message 4,
     literal-token validation, benefit-hook shape, first-party
     trace, and pitch/measured-outcome bans. Sequence Rule 6
     updated to reference the benefit hook instead of the empathy
     line. `produced_by` stamps bumped @0.1.4 → @0.1.6.
  3. `send-scheduled-messages` placeholder substitution spec'd. Step
     2a-i now defines the parse rules for `{first_name}` (whitespace
     split on `Leads.name`, take token zero, strip non-alphabetic
     edges) and `{company}` (verbatim from `Leads.company`). On
     `{first_name}` parse failure the fallback is shape-aware:
     bare-name comma-led (`{first_name}, ...`) drops the prefix and
     capitalizes the next word's first letter, so the body opens
     cleanly without an awkward leading comma; greeting-led
     (`Hi {first_name}, ...`, `Hey {first_name}, ...`) substitutes
     `there`, keeping the greeting intact. Mid-sentence fallback
     defaults to `there`. New post-substitution residue check
     aborts a single send if any literal `{...}` token survives —
     unresolved placeholders never reach the lead. Output block
     gains `skipped_unresolved_placeholder`,
     `first_name_fallback_bare`, and `first_name_fallback_greeting`
     so operators can spot dirty workbook data without grepping
     `_errors.md`. What-NOT-to-do block hardened with five new
     rules covering pre-resolution in approved files, the
     difference between the two fallback paths, and the residue
     check.
- `0.1.7` — Two changes shipped together.
  1. New `connect-only` campaign type. `draft-icp-campaign` now
     asks at the top of Phase 1 whether the campaign is
     `full-sequence` (the existing default — connect + 3-message
     post-accept sequence) or `connect-only` (connection requests
     only, no post-accept sequence). Connect-only branches the
     drafting flow: skips the pain-focus and anchor-phrase
     questions, skips the four-message Sequence section, skips
     Sequence rules 1–9 and the Drafting rule 7 self-check (no
     message bodies to check), runs stop-slop on the spec prose
     only. Connect-only specs use a condensed body template
     (filter summary + target ICP + why-now + lead source + exit
     conditions + daily-cap-share + a "what this campaign does
     NOT do" callout) — no Sequence section, no Booking flow
     section. Front-matter gains `campaign_type`; per-campaign
     ICP and Campaigns sheet schemas extend to carry it.
     `register-campaign` reads the type, validates the spec
     against it (connect-only specs must have empty
     `anchor_phrase`, the right cadence string, and no Sequence
     section), and writes to the Campaigns row. `detect-accepts`
     partitions newly-accepted leads by type — full-sequence
     accepts chain into `generate-message-tasks`, connect-only
     accepts terminate at `state=accepted`. `generate-message-tasks`
     gains a defensive refuse for connect-only leads.
     `outreach-weekly-report` adds a separate "Per campaign —
     connect-only" table (Connects / Accepts / Accept % / Saved
     search status; reply-rate and book-rate columns omitted as
     zero-by-design); the at-a-glance totals continue to sum
     honestly across both types. Pre-0.1.7 specs without a
     `campaign_type` field default to `full-sequence` (back-compat).
  2. `daily-connect` tightened. Front-matter description corrected
     ("BLANK connect requests via the Sales Nav row-level three-dot
     menu" — the prior phrasing said "campaign-specific note" which
     contradicted the spec). Send loop now enshrines the row-level
     three-dot menu method as canonical and warns against the
     side-panel overflow (which sometimes navigates to the full
     profile page instead of opening a dropdown). Three explicit
     skip cases added: Connect–Pending (already invited), 1st-degree
     (already connected — flips state to `connected`), no-Connect-
     option (restricted profile). Save-as-lead checkbox verification
     added to the dialog step. Step numbering renumbered 1–11 to
     fit the new structure.
- `0.1.9` — Briefly shipped the `invite-page-followers` skill (a
  monthly page-growth action against the LinkedIn admin dashboard).
  The skill, its stack.md keys (`page_invite_*`), and its run-log
  surface (`/05_published/outreach/page-invites/`) all moved out of
  this plugin in 0.2.0; see below.
- `0.2.0` — Plugin refocused on lead pipelines only.
  `invite-page-followers` and all its associated config and run-log
  surface moved to the new `rockstarr-social` plugin, which is the
  natural home for "grow the company page" work alongside scheduled
  posts, repurposed content, and other social-channel surfaces.
  Workspaces that were running the page-invite skill from this
  plugin should install `rockstarr-social` and migrate their
  `page_invite_*` stack.md keys there per that plugin's
  Preconditions. This plugin's surface is back to lead-pipeline
  outreach: campaign drafting + connects + sequence + replies +
  bookings. No campaign-side behavior changed — every full-sequence
  and connect-only campaign skill is byte-equivalent to 0.1.9. The
  scope cleanup makes both plugins easier to reason about: the
  campaign workbook stays in this plugin, the page-growth surface
  stays in rockstarr-social, and the LinkedIn account health budget
  is shared between them via the same `confirm-session` gate that
  every Sales Nav skill already runs through.
- `0.2.1` — Connect-only campaigns now surface their accepting
  leads by name. `detect-accepts` adds a publish-log write to
  `/05_published/outreach/<today>.md` on any run that produces
  accepts — full-sequence accepts get a count-only summary
  (the downstream sequence is where the real signal lives), and
  connect-only accepts get a per-lead named list as
  `<Name> (<title> at <company>)` because the accept IS the
  success event for those campaigns. Skipped on quiet days. The
  output block grows: `newly_accepted` now carries
  `lead_name` / `lead_company` / `lead_title` inline, and a new
  `connect_only_accepts_by_campaign` map gives downstream
  callers the per-slug named lists without re-reading Leads.
  `outreach-weekly-report` adds an "Accepted this week — named
  list" sub-block under the existing "Per campaign —
  connect-only" section, listing each campaign's accepting leads
  sorted most-recent-first with a 15-name soft cap and overflow
  pointer to the workbook. Full-sequence campaigns do NOT get a
  parallel named-accepts block — their accept is intermediate, not
  a success event, and the named events surface downstream in
  replies and bookings. No workbook schema changes — the existing
  `Leads.state=accepted` + `date_accepted` + `campaign_slug`
  columns are the source of truth; this release just surfaces that
  data in two more places (daily activity log + Friday report) so
  the operator never has to open the workbook to see who joined a
  network-build audience.
- `0.3.0` — Chrome MCP × Sales Nav reality alignment plus scheduling
  guidance, driven by field data from the first full-volume
  rockstarr-outreach-salesnav rollout. Three shipped together (one
  PR each, all targeting 0.3.0):
  1. `daily-connect` + `send-scheduled-messages` reworked. The
     previously-canonical "row-level three-dot menu on the
     saved-search page" path is unreachable in Chrome MCP because
     Sales Nav virtualizes saved-search rows and they don't hydrate
     within `Runtime.evaluate`'s window. New canonical:
     `lead_profile_overflow` — direct navigation to each lead's
     `/sales/lead/[urn]` page (which itself registers the profile
     view for the dedup filter), then the lead-page overflow menu.
     `side_preview_overflow` documented as the human-natural
     fallback that only becomes viable if Sales Nav fixes its
     virtualization timing. Pacing rewritten to 60–90s per-lead
     jitter PLUS a full page refresh after every 3 successful
     sends — passive cooldowns alone hit a 3–5 send ceiling
     because the SPA's JS state accumulates; a reload is the only
     thing that reliably clears it. Pure-JS one-shot click pattern
     is now primary (refs from `read_page` expire mid-batch on
     the SPA). Verify regex uses em-dash explicitly ("Connect — Pending",
     U+2014). New terminal skip reason `requires_email` for leads
     whose Sales Nav privacy setting blocks blank invites — flips
     `Leads.state` to `requires_email_skip` so the lead is never
     re-surfaced. In-run retry semantics for `send_not_confirmed`
     (one pass at end-of-queue after a page refresh, then abandon).
     Output schema gains `per_path`, `retried`, `retry_failed`,
     `page_refreshes`. `send-scheduled-messages` inherits the same
     pacing and click pattern. New optional `stack.md` keys
     `daily_connect_path` and `daily_connect_fallback_path` with
     sensible defaults.
  2. `crawl-lead-list` is now idempotent. New step 0 reads existing
     Leads for the campaign, computes remaining target, returns
     `noop` if already met, and uses an existing-URL set to silently
     skip already-crawled leads on resumption. Per-row hydration:
     `scrollIntoView` each row individually and poll up to 4s for
     its `<article>` to populate (replaces the broken whole-page
     wait that returned before most rows hydrated). Commit-only-
     fully-hydrated contract: rows with blank `company` or `title`
     are logged as warnings and skipped — partial rows poison the
     exclusion filter and downstream ICP sanity checks. Output
     schema becomes structured: `status` (complete / partial /
     aborted / noop), `existing_count_before`, `inserted_this_run`,
     `total_after`, `pages_walked`, hydration counts. New "Caller-
     side smart-defer" section documents the recommended gating
     rule for daily loops (only invoke when
     `queued + today_budget < target_lead_count × 1.5`).
  3. Scheduling guidance documented. The README's Daily Operational
     Loop section gains a "Scheduling the loop" subsection covering
     the split-task pattern (recommended for full-volume workspaces:
     one task for accepts/messages/replies + another for connects,
     60-minute offset), the rationale (Cowork's per-scheduled-task
     turn budget), and the optional `crawl-on-shortfall` pre-step
     for the connects task. New "Scheduling environment" subsection
     surfaces the laptop-awake expectation (tasks fire when Claude
     Desktop is running, not when the OS clock ticks) and the
     Chrome MCP tab-group reality (each scheduled task creates its
     own auto-named group; cross-session consolidation is not in
     the Chrome MCP API and loop prompts should not try to do it).
- `0.2.2` — `daily-connect` Send loop reordered: click the lead's
  name first to register a profile view in the Sales Nav side
  preview, THEN open the row-level three-dot menu. The
  operator's saved searches are configured to hide already-viewed
  profiles so each day's queue starts at the top with fresh
  names; the previous loop skipped the name-click and left every
  touched lead in tomorrow's results, corrupting the
  "start-at-the-top" workflow. The new Step 3 clicks the name
  link via Chrome MCP `find` (lead's name as the accessible name
  on the `<a>` element in the search row), confirms the side
  preview populated before continuing, and includes a fallback
  for Sales Nav UI variants that route the name link to the full
  profile page instead of the side panel (use browser back; the
  navigation itself counts as a profile view). The profile-view
  registration applies to skipped leads too — Connect-Pending,
  1st-degree, and no-Connect-option cases all hit Step 3 before
  the skip-check in Step 4, so every lead the bot touches drops
  off the next-day queue regardless of whether the connect went
  through. Send loop renumbered 1–12 to fit. Two new
  What-NOT-to-do bullets enforce the new ordering. Front-matter
  description updated to name the click-first pattern so other
  skills discovering this one via description see the contract.
- Deferred to later versions: `force-send-today`, `refresh-lead-list`,
  `gcal-auto-booking`, weighted multi-campaign pacing, cross-bot touch
  caps.
- The two "shared" skills (`draft-icp-campaign`, `propose-meeting-times`)
  ship inline in this plugin for V0.1 so it's self-contained. When
  `rockstarr-outreach-interceptly` lands, both move to
  `rockstarr-infra/skills/_shared/` and the plugin-level wrappers call
  the shared source.

## What this plugin does not do

- Does not install or talk to Interceptly, MeetAlfred, Dripify, Waalaxy.
- Does not send email, schedule social posts, or drive CRM.
- Does not run monthly page-follow invites. That work moved to the
  `rockstarr-social` plugin in 0.2.0; install it alongside this one
  if you want both pipeline outreach and page-growth automation.
- Does not approve its own campaigns, replies, or bookings.
- Does not hand the booking link to the lead. Ever.
- Does not silently retry after a `confirm-session` failure. Wrong-
  account sending is the top reputational risk in this pillar.
